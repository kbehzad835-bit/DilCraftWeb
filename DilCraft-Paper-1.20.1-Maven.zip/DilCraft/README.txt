DilCraft - Paper 1.20.1 + Maven

Build:
  mvn clean package

JAR:
  target/DilCraft-1.0.0.jar

Install:
1. Put the JAR in plugins/.
2. Start the server once.
3. Edit plugins/DilCraft/config.yml.
4. Put your Linabase anon key in api-key.
5. Restart.

Commands:
  /dil
  /dil set <player> <amount>
  /dil add <player> <amount>
  /dil remove <player> <amount>

The Linabase table must contain:
  username TEXT UNIQUE NOT NULL
  dil BIGINT NOT NULL DEFAULT 0

Important:
The anon key is subject to Linabase RLS. SELECT and UPDATE/PATCH need policies
that allow the requested operation. For production server-side use, Linabase
documents service_role as the server-side key, but never publish that key.

Never upload config.yml with a real key to GitHub.
